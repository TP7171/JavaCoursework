/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

/**
 *
 * @author thiag
 */
public class Saver {

    //Method to save all the array information in the file
    public static void saver(List<Patient> PatientListIn) {

        //Using of the trycatch to avoid exception
        try (
                FileWriter patientFile = new FileWriter("file.txt");
                PrintWriter patientSaver = new PrintWriter(patientFile);) {

            for (Patient item : PatientListIn) {
                patientSaver.println(item.getName());
                patientSaver.println(item.getdOfB());
                patientSaver.println(item.getmOfB());
                patientSaver.println(item.getyOfB());
                patientSaver.println(item.getAddress());
                patientSaver.println(item.getDescription());
                patientSaver.println(item.getFire());
                patientSaver.println(item.getNhs());
                patientSaver.println(item.getPolice());

            }
        } catch (IOException e) {
            System.out.println("There was a problem writing the file");
        }

    }
}
